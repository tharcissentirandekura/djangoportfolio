var typed = new Typed('h2', {
    strings: ["Software engineer"],
    typeSpeed: 60,
    backSpeed : 60,
    loop:true
    });